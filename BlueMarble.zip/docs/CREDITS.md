```
██████╗ ██╗     ██╗   ██╗███████╗
██╔══██╗██║     ██║   ██║██╔════╝
██████╔╝██║     ██║   ██║█████╗  
██╔══██╗██║     ██║   ██║██╔══╝  
██████╔╝███████╗╚██████╔╝███████╗
╚═════╝ ╚══════╝ ╚═════╝ ╚══════╝


███╗   ███╗ █████╗ ██████╗ ██████╗ ██╗     ███████╗
████╗ ████║██╔══██╗██╔══██╗██╔══██╗██║     ██╔════╝
██╔████╔██║███████║██████╔╝██████╔╝██║     █████╗  
██║╚██╔╝██║██╔══██║██╔══██╗██╔══██╗██║     ██╔══╝  
██║ ╚═╝ ██║██║  ██║██║  ██║██████╔╝███████╗███████╗
╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝
```

---------------------------------------------------

"Blue Marble" is made by SwingTheVine

The favicon "Blue Marble" is owned by NASA

Special Thanks:
* nof, [darkness](https://github.com/TouchedByDarkness) for creating similar userscripts!
* [BullStein](https://github.com/BullStein), [allanf181](https://github.com/allanf181) for being early beta testers!
* guidu_ for the "Minimize" Button code!
* Nomad for the tutorial!
* TheBlueCorner for getting me interested in online pixel canvases!