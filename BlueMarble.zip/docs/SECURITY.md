<h1>Reporting A Security Vulnerability</h1>
<a href="" target="_blank" rel="noopener noreferrer"><img alt="CodeQL" src="https://github.com/SwingTheVine/Wplace-BlueMarble/actions/workflows/github-code-scanning/codeql/badge.svg"></a>
<p>
  Since this is a userscript, there will not be many vulnerabilities. The user is in charge of their own security, by choosing which scripts to run. Regardless, if you do find a security vulnerability in Blue Marble, please report it on the GitHub Security Advisory <a href="https://github.com/SwingTheVine/Wplace-BlueMarble/security/advisories/new">"Report a Vulnerability"</a> tab.
</p>